import 'package:shopping_junction/models/products.dart';
import 'package:shopping_junction/models/subcategory_model.dart';

class SubList{
  String name;
  List<SubCategory> subCateogry;

  SubList({this.name,this.subCateogry});
}

