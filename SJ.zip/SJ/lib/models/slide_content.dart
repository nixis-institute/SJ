class SlideContent {
  String imageUrl;
  String name;
  double discount;
  int price;

  SlideContent({
    this.imageUrl,
    this.name,
    this.discount,
    this.price,
  });
}

// final List<SlideContent> slider_images = [
//   SlideContent(
//     imageUrl: 'assets/slider/1.JPG',
//     name: 'Get 50% Off',
//     discount: 2,
//     price: 175,
//   ),
//   SlideContent(
//     imageUrl: 'assets/slider/2.JPG',
//     name: 'Tranding',
//     discount: 5,
//     price: 300,
//   ),
//   SlideContent(
//     imageUrl: 'assets/slider/3.JPG',
//     name: 'Special Deals',
//     price: 240,
//     discount: 0
//   ),
//   SlideContent(
//     imageUrl: 'assets/slider/4.JPG',
//     name: 'Exclusive',
//     price: 100,
//     discount: 1
//   ),
// ];